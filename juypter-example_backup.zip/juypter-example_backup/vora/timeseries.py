# -*- coding: utf-8 -*-
"""
Created on Wed Sep 19 12:11:05 2018

@author: M1030622
"""


import pandas as pd
iter_csv = pd.read_csv('D:\\Data\\Reshma\\Processed\\part.tar\\part\\final_cluster_correct2.csv', iterator=True, chunksize=1000)
df = pd.concat(chunk.loc[((chunk['age'].astype(int)) > 10) & ((chunk['age'].astype(int)) < 21)] for chunk in iter_csv)

df.head()

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

df.dtypes

df['date'] =  pd.to_datetime(df['date'], format='%Y-%m-%d')

df.head()

df_agegroup1final = df.groupby('date')['impressions'].sum()

dframe_agegroup1 = df_agegroup1final.to_frame()
dframe_agegroup1.head()

#mean for all 3 months
agegroup1_Jan_Mean = dframe_agegroup1['2018-01-01':'2018-01-31'].mean()
agegroup1_Feb_Mean = dframe_agegroup1['2018-02-01':'2018-02-28'].mean()
agegroup1_March_Mean = dframe_agegroup1['2018-03-01':'2018-03-31'].mean()

#std for all 3 month
agegroup1_Jan_Std = dframe_agegroup1['2018-01-01':'2018-01-31'].std()
agegroup1_Feb_Std = dframe_agegroup1['2018-02-01':'2018-02-28'].std()
agegroup1_March_Std = dframe_agegroup1['2018-03-01':'2018-03-31'].std()

print("agegroup1_Jan_Mean",agegroup1_Jan_Mean)
print("agegroup1_Feb_Mean",agegroup1_Feb_Mean)
print("agegroup1_March_Mean",agegroup1_March_Mean)

print("agegroup1_Jan_std",agegroup1_Jan_Std)
print("agegroup1_Feb_std",agegroup1_Feb_Std)
print("agegroup1_March_std",agegroup1_March_Std)

sns.distplot(dframe_agegroup1['2018-01-01':'2018-01-31'])
dframe_agegroup1['2018-01-01':'2018-01-31'].head()

sns.distplot(dframe_agegroup1['2018-02-01':'2018-02-28'])

def outlier_Detection(df,mean,std,lbd):
    UCL = mean + std
    LCL = mean - std
    
    month_data = df[lbd:lbd]
    month_data.loc[month_data['impressions'] > UCL['impressions'],'impressions'] = UCL['impressions']
    if LCL['impressions'] > 0:
        month_data.loc[month_data['impressions'] < LCL['impressions'],'impressions'] = LCL['impressions']
    return month_data

month1_data = outlier_Detection(dframe_agegroup1,agegroup1_Jan_Mean,agegroup1_Jan_Std,'2018-01')
month2_data = outlier_Detection(dframe_agegroup1,agegroup1_Feb_Mean,agegroup1_Feb_Std,'2018-02')
month3_data = outlier_Detection(dframe_agegroup1,agegroup1_Jan_Mean,agegroup1_Jan_Std,'2018-03')

sns.distplot(month3_data)

outlier_free_df = pd.concat([month1_data,month2_data,month3_data])
outlier_free_df.plot()
dframe_agegroup1.plot()
plt.show()


outlier_free_df1 = plt.plot(outlier_free_df,color='blue',label='outlier_free')
dframe_agegroup1 = plt.plot(dframe_agegroup1,color='red',label='with_outlier')

plt.legend()
plt.title('Rolling mean and standard deviation')
plt.show()
plt.plot()

from statsmodels.tsa.stattools import adfuller

def test_stationary(data):
    rolmean = data.rolling(12).mean()
    rolstd = data.rolling(12).std()


    orignal = plt.plot(data,color='blue',label='orignal')
    mean = plt.plot(rolmean,color='red',label='Rolling mean')
    std = plt.plot(rolstd,color='green',label='Rolling std')
    plt.legend()
    plt.title('Rolling mean and standard deviation')
    plt.show()

    #df test
    dftest = adfuller(data.iloc[:,0].values,autolag='AIC')
    dfoutput = pd.Series(dftest[0:4], index=['Test Statistic','p-value','#Lags Used','Number of Observations Used'])
    dfoutput    

    for key, value in dftest[4].items():
        dfoutput['Critical value (%s)'%key] = value

    print(dfoutput)

test_stationary(outlier_free_df)

from statsmodels.tsa.stattools import acf, pacf

lag_acf = acf(outlier_free_df,nlags=10)
plt.plot(lag_acf)

lag_pacf = pacf(outlier_free_df,nlags=10,method='ols')
plt.plot(lag_pacf)

from statsmodels.tsa.arima_model import ARIMA
import warnings
warnings.filterwarnings('ignore')

from pyramid.arima import auto_arima
stepwise_model = auto_arima(outlier_free_df, start_p=1, start_q=1,
                            max_p=2, max_q=2, m=12,
                            start_P=0, seasonal=True,
                            d=1, D=1, trace=True,
                            error_action='ignore',  
                            suppress_warnings=True, 
                            stepwise=True)
print(stepwise_model.aic())


model = ARIMA(outlier_free_df,order=(2,0,0))
result_AR = model.fit(disp=-1)
#result_AR.fittedvalues
plt.plot(outlier_free_df)
plt.plot(result_AR.fittedvalues)

pre_df=result_AR.fittedvalues.to_frame(name='imp')
pre_df.head()

# ARdf = pd.DataFrame(result_AR.fittedvalues, columns=['#Passengers'])

# #RSS
# p = (ARdf-ts_log1_diff)**2
# p.sum()

from sklearn.utils import check_array
def mean_absolute_percentage_error(y_true, y_pred): 
    y_true, y_pred = check_array(y_true, y_pred)

    ## Note: does not handle mix 1d representation
    #if _is_1d(y_true): 
    #    y_true, y_pred = _check_1d_array(y_true, y_pred)

    return np.mean(np.abs((y_true - y_pred) / y_true)) * 100

y_true=list(outlier_free_df['impressions'])

y_pred=list(pre_df['imp'])

mean_absolute_percentage_error(y_true, y_pred)

outlier_free_df
for i in iter_csv:
    print(i)

data = pd.read_csv("D:\\Data\\Reshma\\Processed\\part.tar\\part\\Voiro.csv")

pd.read_csv()


